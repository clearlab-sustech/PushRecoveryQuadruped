#ifndef _convexMPC_util
#define _convexMPC_util

#include "common_types.h"
#include <eigen3/Eigen/Dense>

#endif
